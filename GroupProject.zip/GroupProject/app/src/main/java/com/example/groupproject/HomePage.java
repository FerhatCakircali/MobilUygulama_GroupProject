package com.example.groupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class HomePage extends AppCompatActivity {

    private TextView txtDene;
    private String birlestir;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        txtDene=findViewById(R.id.tvAdSoyad);
        Intent intent = getIntent();
        String ad = intent.getStringExtra("ad");
        String soyad = intent.getStringExtra("soyad");

        birlestir= ad + " " + soyad;
        txtDene.setText(birlestir);

    }
    public void clcGoImage(View v)
    {
        Intent intent= new Intent(HomePage.this, Photos.class);
        startActivity(intent);
    }
}